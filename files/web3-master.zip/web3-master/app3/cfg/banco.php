<?php

$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'app3',
    'usuario' => 'root',
    'senha' => '',
];
