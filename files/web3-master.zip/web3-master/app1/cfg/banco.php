<?php

$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'app1',
    'usuario' => 'root',
    'senha' => '',
];
