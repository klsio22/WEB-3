CREATE DATABASE app0 COLLATE 'utf8_unicode_ci';
