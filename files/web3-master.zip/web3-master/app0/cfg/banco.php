<?php

$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'app0',
    'usuario' => 'root',
    'senha' => '',
];
