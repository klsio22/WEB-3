<?php

$rotas = [
    '/' => [
        'GET' => '\Controlador\AppControlador#index',
    ]
];
