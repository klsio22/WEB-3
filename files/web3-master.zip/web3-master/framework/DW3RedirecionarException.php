<?php
namespace Framework;

class DW3RedirecionarException extends \Exception
{
}