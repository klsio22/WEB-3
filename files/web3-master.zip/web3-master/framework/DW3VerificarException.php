<?php
namespace Framework;

class DW3VerificarException extends \Exception
{
}