<?php

$banco = [
    'driver' => 'mysql',
    'servidor' => 'localhost',
    'porta' => '3306',
    'banco' => 'app2',
    'usuario' => 'root',
    'senha' => '',
];
