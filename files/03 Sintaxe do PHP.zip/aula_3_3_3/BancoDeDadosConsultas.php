<?php
namespace Aplicacao\Modelo;

trait BancoDeDadosConsultas
{
    public function consultar()
    {
        echo "Consultando... OK\n";
    }
}
