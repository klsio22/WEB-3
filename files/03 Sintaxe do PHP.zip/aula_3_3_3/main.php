<?php
namespace Aplicacao\Modelo;

require_once 'BancoDeDados.php';

$bancoDeDados = new BancoDeDados();

$insercoes = $bancoDeDados->getQuantidadeInsercoes();
echo "Existe(m) $insercoes registro(s) no banco de dados.\n";

$bancoDeDados->inserir();
$bancoDeDados->consultar();

$insercoes = $bancoDeDados->getQuantidadeInsercoes();
echo "Existe(m) $insercoes registro(s) no banco de dados.\n";