<?php
namespace Aplicacao\Modelo;

require_once 'BancoDeDadosConsultas.php';
require_once 'BancoDeDadosInsercoes.php';

class BancoDeDados
{
	/* inclusão das traits na classe */
	use BancoDeDadosConsultas;
	use BancoDeDadosInsercoes;
}
