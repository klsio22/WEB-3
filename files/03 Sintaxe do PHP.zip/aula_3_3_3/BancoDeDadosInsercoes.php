<?php
namespace Aplicacao\Modelo;

trait BancoDeDadosInsercoes
{
	private $insercoes = 0;

    public function inserir()
    {
        echo "Inserindo... OK\n";
        $this->insercoes++;
    }

    public function getQuantidadeInsercoes()
    {
    	return $this->insercoes;
    }
}
