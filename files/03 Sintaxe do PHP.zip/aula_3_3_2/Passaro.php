<?php
namespace Aplicacao\Modelo;

require_once 'Animal.php';

class Passaro extends Animal
{
    public function __construct($nome)
    {
        parent::__construct($nome);
    }

    public function falar()
    {
        echo "Piu\n";
    }
}
