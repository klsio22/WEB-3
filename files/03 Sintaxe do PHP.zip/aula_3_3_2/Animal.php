<?php
namespace Aplicacao\Modelo;

require_once 'SerVivo.php';

abstract class Animal implements SerVivo
{
    /* não produz o próprio alimento? */
    const HETEROTROFO = true;

    protected $nome;

    public function __construct($nome)
    {
        $this->nome = $nome;
    }

    /* método da interface */
    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    /* método estático */
    public static function isHeterotrofo()
    {
        return self::HETEROTROFO;
    }

    /* método abstrato */
    abstract public function falar();
}
