<?php
namespace Aplicacao\Modelo;

require_once 'Animal.php';

class Vaca extends Animal
{
    public function __construct($nome)
    {
        parent::__construct($nome);
    }

    public function falar()
    {
        echo "Muuu\n";
    }
}
