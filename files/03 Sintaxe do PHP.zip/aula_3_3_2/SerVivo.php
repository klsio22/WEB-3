<?php
namespace Aplicacao\Modelo;

interface SerVivo
{
    public function getNome();
}
