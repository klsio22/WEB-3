<?php
namespace Aplicacao\Modelo;

require_once 'Passaro.php';
require_once 'Vaca.php';

// $serVivo = new SerVivo();
// PHP Fatal error:  Uncaught Error: Cannot instantiate interface Aplicacao\Modelo\SerVivo

// $animal = new Animal();
// PHP Fatal error:  Uncaught Error: Cannot instantiate abstract class Aplicacao\Modelo\Animal

$passaro = new Passaro('Canário');
echo 'Nome do pássaro: ' . $passaro->getNome() . "\n";
$passaro->falar();

$vaca = new Vaca('Jairo');
echo 'Nome da vaca: ' . $vaca->getNome() . "\n";
$vaca->falar();

echo "\nProduz o próprio alimento?\n";
echo $vaca::HETEROTROFO ? 		"\tSim\n" : "\tNão\n";
echo $vaca::isHeterotrofo() ? 	"\tSim\n" : "\tNão\n";
echo Animal::HETEROTROFO ? 		"\tSim\n" : "\tNão\n";
echo Animal::isHeterotrofo() ? 	"\tSim\n" : "\tNão\n";

/* Comparação de objetos */

$canario1 = new Passaro('Canário');
$canario2 = new Passaro('Canário');
$calopsita = new Passaro('Calopsita');
// compara atributos
$comparacao1 = ($canario1 == $canario2  ? 'Iguais' : 'Diferentes');
// compara atributos e tipos
$comparacao2 = ($canario1 === $canario2 ? 'Iguais' : 'Diferentes');
// compara atributos
$comparacao3 = ($canario1 == $calopsita ? 'Iguais' : 'Diferentes');
echo "\ncanario1 == canario2: $comparacao1\n";
echo "canario1 === canario2: $comparacao2\n";
echo "canario1 == calopsita: $comparacao3\n\n";
