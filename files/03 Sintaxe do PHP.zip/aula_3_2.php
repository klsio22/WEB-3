<?php

/* ==========================================================================================
1 - FUNÇÃO
========================================================================================== */


function formatarString(string $nome = 'Alan Turing')
{
    return "$nome foi o pai da computação.\n";
}

$texto1 = formatarString();
$texto2 = formatarString('Jair do Caminhão');
echo "1.1 - $texto1";
echo "1.2 - $texto2";
echo "\n";


/* ==========================================================================================
2 - PASSAGEM POR REFERÊNCIA
========================================================================================== */


function incrementar(&$valorReferencia)
{
    $valorReferencia++;
}

$valorReferencia = 1;
incrementar($valorReferencia);

echo "2.1 - A função alterou o valor: $valorReferencia.\n\n";


/* ==========================================================================================
3 - FUNÇÃO ANÔNIMA
========================================================================================== */


$minhaFuncao = function () {
    return "Sou uma função anônima.\n";
};
$texto = $minhaFuncao();
echo "3.1 - $texto";

// ---------------------------------------------

function rodar($funcao)
{
	$funcao();
}

rodar(function () {
	echo "3.2 - Sou outra função anônima.\n\n";
});
