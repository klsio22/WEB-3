<?php

/* ==========================================================================================
1 - DECLARAÇÃO DE VARIÁVEL
O identificador (nome) deve começar com $
Não precisa declarar o tipo
A função 'define' cria uma constante
========================================================================================== */

$nada = null;
$booleano = true;
$inteiro = 1;
$real = 3.14;
$texto = "UTFPR";

// sempre que precisar verificar o conteúdo e tipo de uma variável, usar a função var_dump()
echo '1.1 - Depurando: ';
var_dump($texto);

define('MINUTO', 60);
define('HORA', MINUTO * 60);
echo "1.2 - Um dia tem " . (24*HORA) . " segundos\n\n";

/* ==========================================================================================
2 - STRINGS E IMPRESSÃO
concatenação e interpolação
========================================================================================== */

echo "2.1 - Concatenando " . "duas strings\n"; // concatenação com o ponto
echo "2.2 - Concatenando com variável: " . $real . "\n";
echo "2.3 - Interpolação com variável: $real\n"; // o PHP aceita variáveis no meio da string
echo '2.4 - Sem interpolação: $real\n'; // não interpola com aspas simples
echo "\n\n";


/* ==========================================================================================
3 - ESTRUTURAS DE CONTROLE
========================================================================================== */

$valor = 0;
if ($valor > 0) {
    echo "3.1 - Maior que zero\n";

} elseif ($valor < 0) {
    echo "3.1 - Menor que zero\n";

} else {
    echo "3.1 - Zero\n";
}

$valor = 0;
if ($valor == false) {
    echo "3.2 - Conversão automática de tipos\n"; // zero vale o mesmo que false
}

if ($valor === false) { // também compara os tipos das variáveis
    echo "Erro";
} else {
    echo "3.3 - Sem conversão automática de tipos\n";
}

// IF TERNÁRIO
echo $valor == 0 ? "3.4 - Zero\n\n" : "3.4 - Não é zero\n\n";


/* ==========================================================================================
4 - ESTRUTURAS DE REPETIÇÃO
========================================================================================== */

$x = 0;
while ($x < 3) {
    echo "4.1 - Laço WHILE: $x\n";
    $x++;
}

// PHP também suporta 'do-while', 'break' e 'continue'

for ($x = 0; $x < 3; $x++) {
    echo "4.2 - Laço FOR: $x\n";
}

echo "\n";

/* ==========================================================================================
5 - VETORES
O índice sempre começa no zero
========================================================================================== */

$vetor = array(1, 9.99, 'texto'); // sintaxe antes da versão 5.4
$vetor = [1, 9.99, 'texto']; // sintaxe a partir da versão 5.4

$vetor[] = 'novo elemento'; // adiciona no final do vetor
echo "5.1 - $vetor[3]\n";

unset($vetor[3]); // remove um elemento

// FOR para vetores: ele percorre os elementos do vetor
foreach ($vetor as $elemento) {
    echo "5.2 - Elemento: $elemento\n";
}

echo "\n";

/* ==========================================================================================
5 - MATRIZES
No PHP, uma matriz é um vetor que possui outro vetor como elemento
========================================================================================== */

// Um elemento pode ter qualquer tipo
$vetor = [
    [1,2,3],
    [5,6],
    'João'
];

echo "5.1 - Matriz: {$vetor[0][0]}\n"; // verifica o conteúdo das chaves como uma variável
echo "5.2 - Matriz: " . $vetor[0][0] . "\n\n"; // concatenando


/* ==========================================================================================
6 - DICIONÁRIO (HASH)
É um vetor em que você escolhe as chaves (índices)
========================================================================================== */

$vetor = [
    'nome' => 'Maria',
    'idade' => 20
];

$vetor['telefone'] = '99999-9999';

echo "6.1 - Nome: $vetor[nome]\n";
echo "6.2 - Idade: " . $vetor['idade'] . "\n"; // concatenando
echo "6.3 - Telefone: $vetor[telefone]\n\n";
