<?php
namespace Aplicacao\Modelo;

require_once 'Pessoa.php'; // procura na mesma pasta

$pessoa = new Pessoa('Fulano'); // funciona porque está no mesmo namespace
echo 'Nome da pessoa: ' . $pessoa->getNome() . "\n";

$pessoa = new \Aplicacao\Modelo\Pessoa('Ciclano');
echo 'Nome da pessoa: ' . $pessoa->getNome() . "\n";
