<?php
namespace Aplicacao\Modelo;

class Pessoa
{
    private $nome;

    /* construtor */
    public function __construct($nome)
    {
        $this->nome = $nome;
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }
}
