<?php
// não tem namespace

require_once 'Pessoa.php';

use Aplicacao\Modelo\Pessoa;

$pessoa = new Pessoa('Fulano'); // funciona por causa do USE
echo 'Nome da pessoa: ' . $pessoa->getNome() . "\n";

$pessoa = new \Aplicacao\Modelo\Pessoa('Ciclano');
echo 'Nome da pessoa: ' . $pessoa->getNome() . "\n";
