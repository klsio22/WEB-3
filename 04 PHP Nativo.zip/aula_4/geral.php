<?php

function imprimirTitulo($titulo) {
	echo str_repeat('=', 30) . "\n\t$titulo\n" . str_repeat('=', 30) . "\n\n";
}
