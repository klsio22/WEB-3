<?php
echo "Olá PHP!\n";
?>
