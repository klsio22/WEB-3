<?php
require_once 'geral.php';

imprimirTitulo('DIRETÓRIO');

print_r(scandir('.'));
echo "\n";
